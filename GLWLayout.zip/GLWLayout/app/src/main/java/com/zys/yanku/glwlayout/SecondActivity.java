package com.zys.yanku.glwlayout;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.zys.yanku.glwlayout.bean.InfoBean;
import com.zys.yanku.glwlayout.method.ColorShowMethod;

/**
 * @author zhaoyasong
 * @date 03/11/2017 13:51
 * @description 创建要跳转到的界面
 */
public class SecondActivity extends AppCompatActivity {

    private ImageView mGetImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        initView();
        //接受传递过来的界面
        TransitionsHeleper.getInstance()
                .setShowMethod(new ColorShowMethod(R.color.bg_teal_light,
                        R.color.bg_teal) {
                    @Override
                    public void loadCopyView(InfoBean bean, ImageView copyView) {
                        Glide.with(SecondActivity.this)
                                .load(bean.getImgUrl())
                                .centerCrop()
                                .into(copyView);
                    }

                    @Override
                    public void loadTargetView(InfoBean bean, ImageView targetView) {
                        Glide.with(SecondActivity.this)
                                .load(bean.getImgUrl())
                                .centerCrop()
                                .into(targetView);
                    }

                }).show(this, mGetImg);

    }

    private void initView() {
        mGetImg = (ImageView) findViewById(R.id.get_img);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        TransitionsHeleper.unBind(this);
    }
}

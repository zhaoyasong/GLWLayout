package com.zys.yanku.glwlayout.method;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AccelerateInterpolator;

import com.zys.yanku.glwlayout.bean.InfoBean;
import com.zys.yanku.glwlayout.view.RenderView;

/**
 * @author zhaoyasong
 * @date 03/11/2017 13:54
 * @description 创建有内容显示的方法
 */
public abstract class InflateShowMethod extends ShowMethod {

    public View inflateView;

    public InflateShowMethod(Activity activity, int layoutId) {
        this.inflateView = LayoutInflater.from(activity).inflate(layoutId, null);
    }

    @Override
    public void translate(InfoBean bean, RenderView parent, View child) {
        set.playTogether(
                ObjectAnimator.ofFloat(child, "translationX", 0, -bean.translationX),
                ObjectAnimator.ofFloat(child, "translationY", 0, -bean.translationY),
                ObjectAnimator.ofFloat(child, "scaleX", 1, 1 / bean.scalling),
                ObjectAnimator.ofFloat(child, "scaleY", 1, 1 / bean.scalling)
        );
        set.setInterpolator(new AccelerateInterpolator());
        set.setDuration(duration).start();
    }

}

package com.zys.yanku.glwlayout;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

/**
 * @author zhaoyasong
 * @date 03/11/2017 13:51
 * @description 创建主界面
 */
public class HomeActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView mJumpImg;
    private final static String img_url = "http://imga.mumayi.com/android/wallpaper/2012/01/02/sl_600_2012010206150877826134.jpg";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        init();
    }

    private void init() {
        initView();
    }

    private void initView() {
        mJumpImg = (ImageView) findViewById(R.id.jump_img);
        Glide.with(this).load(img_url).centerCrop().into(mJumpImg);
        mJumpImg.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.jump_img:
                //点击图片跳转下一个界面
                TransitionsHeleper.startActivity(this, SecondActivity.class, mJumpImg, img_url);
                break;
            default:
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        TransitionsHeleper.unBind(this);
    }
}
